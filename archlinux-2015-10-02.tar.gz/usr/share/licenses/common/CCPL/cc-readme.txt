There are 6 different Creative Commons Licenses, all of which are included
in this licenses directory:

cc-by-3.0.txt       - Attribution
cc-by-nc-3.0.txt    - Attribution-NonCommercial
cc-by-nc-nd-3.0.txt - Attribution-NonCommercial-NoDerivs
cc-by-nc-sa-3.0.txt - Attribution-NonCommercial-ShareAlike
cc-by-nd-3.0.txt    - Attribution-NoDerivs
cc-by-sa-3.0.txt    - Attribution-ShareAlike

If a package uses one of these licenses, it should be referenced as follows:
license=('CCPL:by-nc-sa')
